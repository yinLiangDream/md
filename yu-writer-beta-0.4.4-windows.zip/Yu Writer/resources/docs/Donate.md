打赏
===

如果某一天你发现 Yu Writer 对你有帮助，那就赶紧掏出手机扫下面（右侧即时预览栏）的二维码来打赏我吧！金额随意，上不封顶，次数不限，哈哈哈哈！😄

![使用微信打赏](images/wechat-pay.jpg)

![使用支付宝打赏](images/alipay.jpg)

* * *
返回 [目录](welcome)

